
list =[]
string = 0
for i in range(100,1000):
    string = str(i)
    for k in range(len(string)):
        third_num = string.count(string[k])
        second_num = string.count(string[k - 1])
        first_num = string.count(string[k-2])
    if third_num >=2 or second_num>=2 or first_num >=2:
            list.append(i)
print(*list, sep = ',')








