first_num = int(input("First number:"))
degree = int(input("Degree:"))
result = 1
if degree >= 0:
    for i in range(degree):
        result = result * first_num
elif degree < 0:
    result = first_num ** degree
print(f"Your result is {result}")
