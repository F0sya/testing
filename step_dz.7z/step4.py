from time import sleep
while True:
    string = input("Enter your number:")
    contains_alpha = any(map(str.isalpha, string))
    if contains_alpha == False:
        result_string = string.replace("3", "").replace("6", "")
        print(f"Number without 3 and 6: {int(result_string)}")
        break
    else:
        print("Error.Try again in 3 seconds")
        sleep(3)