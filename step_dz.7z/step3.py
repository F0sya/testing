list =[]
string = 0
for i in range(100,10000):
    string = str(i)
    for k in range(len(string)):
        third_num = string.count(string[k])
        second_num = string.count(string[k - 1])
        first_num = string.count(string[k-2])
    if third_num == 1 and second_num == 1 and first_num  == 1:
            list.append(i)
print(*list, sep = ',')
