from time import sleep
from currency_converter import CurrencyConverter
balance = int(input("How much money you want convert?"))
first_currency = input("Which currency you want to convert?")
second_currency = input("Which currency you want to get from converting?")
list_currency = ["USD","EUR","BGN"]
c = CurrencyConverter()
check = 0
while  check != "Yes":
    check = input("Did you know the list of currencies?")
    if check == "Yes":

        print(c.convert(balance, first_currency,second_currency))
        break
    elif check =="No":
        print(f"List of currencies is {list_currency}")
        sleep(3)
    else:
        print("Error")
        sleep(3)

