from math import gcd

first_num = int(input("Enter first number: "))
second_num = int(input("Enter second number: "))


result = gcd(first_num, second_num)
print(f"The GCD of this number equals {result}")
