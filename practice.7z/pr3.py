from time import sleep
left_limit = int(input("Enter left limit:"))
right_limit = int(input("Enter right limit:"))
string = ""
for i in range(left_limit,right_limit+1):
    string = string + str(i)
while True:
    n = input("Enter a number")
    if n in string:
        print(string.replace(n,f'!{n}!'))
        break
    else: print("Error.Try again in 3 seconds")
    sleep(3)

