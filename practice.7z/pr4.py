from time import sleep
from random import randint
rounds  = int(input("How much rounds you want play?"))
list = ["Rock", "Paper", "Scissors"]
player_points = 0
computer_points = 0
for i in range(1, rounds+1):
    while True:
        player_turn = input("Rock, paper or scissors?")
        computer_turn = list[randint(0,2)]
        if player_turn in list:
            if player_turn == computer_turn:
                print(f"Your choice is {player_turn} vs computer choice is {computer_turn}. Tie!")
            elif player_turn == "Rock" and computer_turn == "Paper":
                print(f"Your choice is {player_turn} vs computer choice is {computer_turn}. Computer wins!")
                computer_points +=1
            elif player_turn == "Rock" and computer_turn == "Scissors":
                print(f"Your choice is {player_turn} vs computer choice is {computer_turn}. Player wins!")
                player_points +=1
            elif player_turn == "Paper" and computer_turn == "Scissors":
                print(f"Your choice is {player_turn} vs computer choice is {computer_turn}. Computer wins!")
                computer_points += 1
            elif player_turn == "Paper" and computer_turn == "Rock":
                print(f"Your choice is {player_turn} vs computer choice is {computer_turn}. Player wins!")
                player_points += 1
            elif player_turn == "Scissors" and computer_turn == "Rock":
                print(f"Your choice is {player_turn} vs computer choice is {computer_turn}. Computer wins!")
                computer_points += 1
            elif player_turn == "Scissors" and computer_turn == "Paper":
                print(f"Your choice is {player_turn} vs computer choice is {computer_turn}. Player wins!")
                player_points += 1
            break
        else:
            print("Error.Try again in 3 seconds")
            sleep(3)

if player_points > computer_points:
    print(f"Player:{player_points} vs Computer:{computer_points}.Player wins")
elif player_points < computer_points:
    print(f"Player:{player_points} vs Computer:{computer_points}.Computer wins")
else:
    print(f"Player: {player_points} vs Computer: {computer_points}.TIE!")






